---
name: Skinberry Clinic Design System
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1a1c1c'
  on-surface-variant: '#4d453e'
  inverse-surface: '#2f3131'
  inverse-on-surface: '#f1f1f1'
  outline: '#7f756d'
  outline-variant: '#d0c5bb'
  surface-tint: '#6b5c4b'
  primary: '#6b5c4b'
  on-primary: '#ffffff'
  primary-container: '#eed9c4'
  on-primary-container: '#6d5e4d'
  inverse-primary: '#d7c3af'
  secondary: '#814f67'
  on-secondary: '#ffffff'
  secondary-container: '#fdbdd8'
  on-secondary-container: '#7a4960'
  tertiary: '#5f5e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#dedcdb'
  on-tertiary-container: '#616060'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#f4dfca'
  primary-fixed-dim: '#d7c3af'
  on-primary-fixed: '#241a0d'
  on-primary-fixed-variant: '#524435'
  secondary-fixed: '#ffd8e7'
  secondary-fixed-dim: '#f4b5d0'
  on-secondary-fixed: '#340d22'
  on-secondary-fixed-variant: '#67384f'
  tertiary-fixed: '#e4e2e1'
  tertiary-fixed-dim: '#c8c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1a1c1c'
  surface-variant: '#e2e2e2'
typography:
  display-lg:
    fontFamily: Manrope
    fontSize: 4.5rem
    fontWeight: '300'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Manrope
    fontSize: 3rem
    fontWeight: '400'
    lineHeight: '1.2'
  headline-lg:
    fontFamily: Manrope
    fontSize: 2.25rem
    fontWeight: '500'
    lineHeight: '1.3'
  headline-md:
    fontFamily: Manrope
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: '1.4'
  body-lg:
    fontFamily: Manrope
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Manrope
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: '1.6'
  label-sm:
    fontFamily: Manrope
    fontSize: 0.75rem
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  section-gap: 120px
  container-max: 1280px
  gutter: 24px
  margin-page: 64px
---

## Brand & Style

This design system is built upon the concept of "Clinical Softness"—a marriage between rigorous medical standards and the indulgent experience of high-end skincare. The brand personality is authoritative yet empathetic, targeting a discerning clientele that values both scientific results and aesthetic refinement. 

The visual style employs a **Modern Minimalist** foundation with **Glassmorphic** accents to suggest transparency and light. The UI prioritizes extreme clarity through generous whitespace (negative space), ensuring that the "Berry" accents feel intentional and precious rather than overwhelming. The emotional response is one of safety, luxury, and rejuvenation.

## Colors

The palette is anchored in clinical purity and skin-health tones. 
- **Primary (#EED9C4):** A warm, sophisticated nude used for large surface areas, subtle section backgrounds, and key decorative elements. It represents the "skin" in Skinberry.
- **Secondary (#8E5A72):** A muted berry tone used exclusively for high-conversion actions and focused brand accents. This provides the "high-end" pop against the neutral base.
- **Tertiary (#333333):** A deep charcoal for all primary text and iconography, ensuring WCAG-compliant legibility while feeling softer and more premium than pure black.
- **Neutral (#F8F8F8 / #FFFFFF):** The foundation of the "medical white" aesthetic, used to create a sterile yet welcoming environment.

## Typography

The typography utilizes **Manrope** for its geometric precision and balanced proportions, echoing the modern clinical feel. 

- **Headlines:** Use lighter weights (300-400) for large display text to evoke elegance, shifting to medium (500-600) for smaller headings to maintain hierarchy.
- **Body:** Standardized at 16px (1rem) for optimal readability with a generous 1.6 line-height to maintain the airy, "breathable" feel of the layout.
- **Labels:** Utilizes a bold, tracked-out uppercase style for small UI elements like category tags or eyebrow headers to add a touch of editorial flair.

## Layout & Spacing

The layout follows a **Fixed Grid** system centered on a 1280px container. This ensures that on large displays, the content feels curated and premium, rather than stretched. 

- **Vertical Rhythm:** A massive `120px` gap between major sections reinforces the high-end aesthetic through "generous whitespace."
- **Grid:** A standard 12-column structure with 24px gutters provides the flexibility to mix imagery and text in asymmetrical patterns, reminiscent of luxury editorial magazines.
- **Padding:** Internal component padding should follow the 8px base unit (e.g., 16px, 24px, 48px).

## Elevation & Depth

To avoid a "flat" medical feel, this design system uses **Ambient Shadows** and **Tonal Layering** to create a sense of physical presence and quality.

- **Surface Layers:** The background is primarily `#FFFFFF`, with `#F8F8F8` used for subtle secondary containers. 
- **Shadows:** Use extremely soft, low-opacity shadows (e.g., `box-shadow: 0 10px 40px rgba(51, 51, 51, 0.05)`). These should be almost imperceptible, serving only to lift "Treatment Cards" and "Booking Modals" off the page.
- **Glassmorphism:** Navigation bars and image overlays should use a 10px backdrop-blur with 80% opacity to maintain a sense of light and transparency.

## Shapes

The shape language is **Rounded (Level 2)**. 

While the clinic is professional, sharp corners can feel aggressive. A 0.5rem (8px) radius on standard components like buttons and inputs strikes the balance between clinical precision and a "welcoming" softness. Image containers and large feature cards may use `rounded-xl` (1.5rem) to soften the visual impact of photography.

## Components

- **Buttons:** 
  - *Primary:* Solid `#8E5A72` (Berry) with white text. High-contrast for "Book Appointment" CTAs.
  - *Secondary:* Outlined or subtle `#EED9C4` background with `#333333` text for "Learn More" actions.
- **Cards:** White backgrounds with the defined "Ambient Shadow." Used for treatment listings and practitioner profiles. They should include generous internal padding (32px).
- **Input Fields:** Minimalist design with a 1px border in a light grey, moving to a `#EED9C4` border on focus. No heavy fills.
- **Chips/Tags:** Used for treatment categories (e.g., "Facial," "Injectables"). Use the Label-sm typography with a light `#EED9C4` background.
- **Imagery:** Photography should be high-key, featuring natural lighting and diverse, healthy skin textures. Avoid overly "plastic" stock photos. 
- **Additional Elements:** Custom thin-stroke icons in `#8E5A72` to guide the user through the service list.